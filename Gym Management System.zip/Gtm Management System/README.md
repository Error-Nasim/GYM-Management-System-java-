# 3rd-Semester-Project
Gym Management System || Software Development Project || Java


Clone this project and run on your NetBeans IDE.
I added a sql (Database.sql) file just run those command on your MySql Workbench or phpmyadmin panel.
Make sure your localhost password is root or not.

![Signup](https://user-images.githubusercontent.com/57921369/178313364-4e9ce14b-c2bf-45bb-9b86-6408e92274e6.png)
![Login](https://user-images.githubusercontent.com/57921369/178313384-0af90b61-ccf8-4835-b518-516bc7752932.png)
![Home](https://user-images.githubusercontent.com/57921369/178313403-3cfc7ef5-5daf-40d6-abb4-3f0206b1a955.png)![Trainer](https://user-images.githubusercontent.com/57921369/178313529-a9474b76-dc5d-4154-917f-6afae549404a.png)
![New Member](https://user-images.githubusercontent.com/57921369/178313565-b60c84ae-e3b8-4ea6-9c8e-8827bbac44bd.png)
![All Member](https://user-images.githubusercontent.com/57921369/178313617-5d6bd80b-c561-457a-b996-34af3e0d8773.png)
![Update](https://user-images.githubusercontent.com/57921369/178313652-bc270982-2167-449c-9481-9586899045a8.png)
![Payment](https://user-images.githubusercontent.com/57921369/178313674-a5ccdf93-5e47-47fd-82af-3fc65f1f0a3d.png)

